<?php
/*
Plugin Name: Emaurri Gutenberg Blocks
Description: Plugin that add blocks for Gutenberg editor
Author: Qode Interactive
Version: 1.0
*/
if ( ! class_exists( 'EmaurriGutenberg' ) ) {
	class EmaurriGutenberg {
		private static $instance;
		
		public function __construct() {
			// Include required files
			require_once 'constants.php';
			require_once 'helpers/helper.php';
			
			// Make plugin available for translation
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
			
			// Register blocks
			$this->init_blocks();
		}
		
		public static function get_instance() {
			if ( self::$instance == null ) {
				self::$instance = new self();
			}
			
			return self::$instance;
		}
		
		function load_plugin_textdomain() {
			// Make plugin available for translation
			load_plugin_textdomain( 'emaurri-gutenberg-blocks', false, EMAURRI_GUTENBERG_REL_PATH . '/languages' );
		}
		
		function init_blocks() {
			
			if ( qode_framework_is_installed( 'gutenberg-editor' ) ) {
				require_once EMAURRI_GUTENBERG_BLOCKS_PATH . '/blocks.php';
				
				foreach ( glob( EMAURRI_GUTENBERG_BLOCKS_PATH . '/*/index.php' ) as $block ) {
					require_once $block;
				}
			}
		}
	}
}

if ( ! function_exists( 'emaurri_gutenberg_blocks_instantiate_plugin' ) ) {
	function emaurri_gutenberg_blocks_instantiate_plugin() {
		EmaurriGutenberg::get_instance();
	}
	
	add_action( 'qode_framework_action_load_dependent_plugins', 'emaurri_gutenberg_blocks_instantiate_plugin' );
}

if( ! function_exists( 'emaurri_gutenberg_blocks_check_requirements' ) ) {
	function emaurri_gutenberg_blocks_check_requirements() {
		if ( ! defined( 'EMAURRI_CORE_VERSION' ) ) {
			add_action( 'admin_notices', 'emaurri_gutenberg_blocks_admin_notice_content' );
		}
	}
	
	add_action( 'plugins_loaded', 'emaurri_gutenberg_blocks_check_requirements', 15 ); // Permission 15 is set because Core plugin is loaded on 10
}

if( ! function_exists( 'emaurri_gutenberg_blocks_admin_notice_content' ) ) {
	function emaurri_gutenberg_blocks_admin_notice_content() {
		echo sprintf( '<div class="notice notice-error"><p>%s</p></div>', esc_html__( 'Emaurri Core plugin is required for Emaurri Gutenberg Blocks plugin to work properly. Please install/activate it first.', 'emaurri-gutenberg-blocks' ) );
		
		if ( function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	}
}