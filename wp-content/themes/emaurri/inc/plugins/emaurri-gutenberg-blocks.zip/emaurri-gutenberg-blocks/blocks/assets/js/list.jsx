// Global wp objects and variables
const {__} = wp.i18n;
const {PanelBody, RangeControl, SelectControl} = wp.components;

const ListOptions = ({props, initialOpen = false}) => {
	const {attributes, setAttributes} = props;
	const {
		behavior,
		columns,
		space,
	} = attributes;
	
	return(
		<PanelBody title={__('List Settings', 'emaurri-gutenberg-blocks')} initialOpen={Boolean(initialOpen)}>
			<SelectControl
				label={__('List Behavior', 'emaurri-gutenberg-blocks')}
				value={behavior}
				options={[
					{label: __('Gallery', 'emaurri-gutenberg-blocks'), value: 'columns'},
					{label: __('Masonry', 'emaurri-gutenberg-blocks'), value: 'masonry'},
					{label: __('Slider', 'emaurri-gutenberg-blocks'), value: 'slider'},
				]}
				onChange={(value) => setAttributes({behavior: value})}
			/>
			<RangeControl
				label={__('Columns Number', 'emaurri-gutenberg-blocks')}
				value={columns}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns: value})}
			/>
			<SelectControl
				label={__('Space Between Items', 'emaurri-gutenberg-blocks')}
				value={space}
				options={[
					{label: __('Huge (40)', 'emaurri-gutenberg-blocks'), value: 'huge'},
					{label: __('Large (25)', 'emaurri-gutenberg-blocks'), value: 'large'},
					{label: __('Medium (20)', 'emaurri-gutenberg-blocks'), value: 'medium'},
					{label: __('Normal (15)', 'emaurri-gutenberg-blocks'), value: 'normal'},
					{label: __('Small (10)', 'emaurri-gutenberg-blocks'), value: 'small'},
					{label: __('Tiny (5)', 'emaurri-gutenberg-blocks'), value: 'tiny'},
					{label: __('No (0)', 'emaurri-gutenberg-blocks'), value: 'no'},
				]}
				onChange={(value) => setAttributes({space: value})}
			/>
		</PanelBody>
	)
};

export default ListOptions;