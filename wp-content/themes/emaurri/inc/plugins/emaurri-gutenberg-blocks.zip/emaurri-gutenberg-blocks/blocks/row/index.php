<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'EmaurriGutenbergRowBlock' ) ) {
	class EmaurriGutenbergRowBlock extends EmaurriGutenbergBlocks {
		private static $instance;
		
		public function __construct() {
			// Set block name
			$this->set_block_name( 'row' );
			
			// Set block attributes
			$this->set_block_attributes( $this->block_attributes() );
			
			// Set block render function
			$this->set_block_render_function( array( $this, 'render_function' ) );
			
			parent::__construct();
		}
		
		public static function get_instance() {
			if ( self::$instance == null ) {
				self::$instance = new self();
			}
			
			return self::$instance;
		}
		
		private function block_attributes() {
			$attributes = array_merge(
				$this->map_core_options(),
				array(
					'columns_layout'      => array(
						'type'    => 'select',
						'default' => 12,
					),
				)
			);
			
			return $attributes;
		}
		
		function render_function( $props ) {
			$props['custom_class'] = $this->block_custom_class( $props );
			
			return null;
		}
	}
	
	EmaurriGutenbergRowBlock::get_instance();
}