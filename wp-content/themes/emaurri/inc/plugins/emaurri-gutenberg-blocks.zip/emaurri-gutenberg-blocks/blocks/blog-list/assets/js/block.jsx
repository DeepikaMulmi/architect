// Global wp objects and variables
const {__} = wp.i18n;
const {registerBlockType} = wp.blocks;
const {Component, Fragment} = wp.element;
const {InspectorControls} = wp.blockEditor;
const {ServerSideRender} = wp.components;

// Block namespace + name
const blockName = 'emaurri-gutenberg-blocks/blog-list';

// Import common block parts
import ListOptions from '../../../assets/js/list.jsx';
import ListResponsiveOptions from '../../../assets/js/list-responsive.jsx';
import QueryOptions from '../../../assets/js/query.jsx';

// Import editor scripts
import { qodefSwiper, qodefMasonryLayout } from './editor-script.jsx';

class BlogListBlock extends Component {
	constructor() {
		super(...arguments);
		
		this.state = {
			behavior: '',
		};
	}
	
	componentDidMount() {
		const {attributes} = this.props;
		
		this.setState({
			behavior: attributes.behavior,
		});
	
		switch (this.state.behavior) {
			case 'masonry':
				this.initMasonry();
				break;
			case 'slider':
				this.initSlider();
				break;
		}
	}
	
	componentDidUpdate(prevProps, prevState) {
		const {attributes} = this.props;
		
		if (prevProps.attributes.behavior !== attributes.behavior) {
			this.setState({
				behavior: attributes.behavior,
			});
		}
		
		switch (this.state.behavior) {
			case 'masonry':
				this.initMasonry();
				break;
			case 'slider':
				this.initSlider();
				break;
		}
	}
	
	initSlider() {
		typeof qodefSwiper === 'object' && qodefSwiper.init();
	}
	
	initMasonry() {
		typeof qodefMasonryLayout === 'object' && qodefMasonryLayout.init();
	}
	
	render() {
		const {attributes} = this.props;
		
		return (
			<Fragment>
				<InspectorControls>
					<ListOptions
						props={this.props}
						initialOpen="true"
					/>
					<ListResponsiveOptions
						props={this.props}
					/>
					<QueryOptions
						props={this.props}
					/>
				</InspectorControls>
				<ServerSideRender
					block={blockName}
					attributes={attributes}
				/>
			</Fragment>
		);
	}
}

// Register block type function
registerBlockType(blockName, {
	icon: 'screenoptions',
	title: __('Blog List', 'emaurri-gutenberg-blocks'),
	description: __('A custom blog list block', 'emaurri-gutenberg-blocks'),
	category: 'emaurri-gutenberg-blocks',
	keywords: [
		__('post', 'emaurri-gutenberg-blocks'),
		__('blog list', 'emaurri-gutenberg-blocks'),
		__('emaurri', 'emaurri-gutenberg-blocks')
	],
	
	edit: BlogListBlock,
	// Render in PHP
	save: () => {
		return null;
	}
});