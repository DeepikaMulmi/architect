/**
 * Init counter
 */
const qodefCounter = {
	init: function () {
		this.holder = document.querySelectorAll('.qodef-counter');
		
		if (this.holder.length) {
			[...this.holder].map(holder => {
				var $thisCounter = holder,
					counterElement = $thisCounter.querySelector('.qodef-m-digit'),
					options = qodefCounter.generateOptions($thisCounter);
				
				qodefCounter.counterScript(counterElement, options);
			});
		}
	},
	generateOptions: function(counter) {
		var options = {};
	
		options.start = typeof counter.getAttribute('data-start-digit') !== 'undefined' && counter.getAttribute('data-start-digit') !== null ? counter.getAttribute('data-start-digit') : 0;
		options.end = typeof counter.getAttribute('data-end-digit') !== 'undefined' && counter.getAttribute('data-end-digit') !== null ? counter.getAttribute('data-end-digit') : 0;
		options.step = typeof counter.getAttribute('data-step-digit') !== 'undefined' && counter.getAttribute('data-step-digit') !== null ? counter.getAttribute('data-step-digit') : 1;
		options.delay = typeof counter.getAttribute('data-step-delay') !== 'undefined' && counter.getAttribute('data-step-delay') !== null ? parseInt( counter.getAttribute('data-step-delay'), 10 ) : 100;
		options.txt = typeof counter.getAttribute('data-digit-label') !== 'undefined' && counter.getAttribute('data-digit-label') !== null ? counter.getAttribute('data-digit-label') : '';
		
		return options;
	},
	counterScript: function (counterElement, options) {
		let nb_start = options.start;
		let nb_end = options.end;
	
		counterElement.textContent = nb_start + options.txt;
		
		const counter = function() {
			// Definition of conditions of arrest
			if (nb_end !== null && nb_start >= nb_end) {
				return;
			}
			// incrementation
			nb_start = Number(nb_start) + Number(options.step);
			
			if( nb_start >= nb_end ) {
				nb_start = nb_end;
			}
			// display
			counterElement.textContent = nb_start + options.txt;
		};
		
		// Timer
		// Launches every "options.delay"
		setInterval(counter, options.delay);
	}
};

export default qodefCounter;