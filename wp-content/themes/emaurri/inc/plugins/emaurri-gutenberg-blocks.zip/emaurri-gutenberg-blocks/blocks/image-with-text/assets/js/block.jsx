// Global wp objects and variables
const {__} = wp.i18n;
const {registerBlockType} = wp.blocks;
const {Component, Fragment, createElement} = wp.element;
const {InspectorControls, MediaUpload} = wp.blockEditor;
const {PanelBody, TextControl, TextareaControl, Button, Icon, ServerSideRender} = wp.components;

// Block namespace + name
const blockName = 'emaurri-gutenberg-blocks/image-with-text';

// Import common block parts
import BlockPlaceholder from '../../../assets/js/placeholder.jsx';

class ImageWithTextBlock extends Component {
	constructor() {
		super(...arguments);
	}
	
	filterAttributes(attr) {
		if (typeof attr === 'object') {
			Object.keys(attr).forEach(key => (typeof attr[key] === 'undefined') && delete attr[key]);
			
			return attr;
		}
		
		return null;
	}
	
	render() {
		const {attributes, setAttributes} = this.props;
		const {
			image,
			imageSrc,
			title,
			text,
		} = attributes;
		
		const qodeblocks = this.filterAttributes({
			image,
			imageSrc,
			title,
			text,
		});

		return (
			<Fragment>
				<InspectorControls>
					<PanelBody title={__('Block Settings', 'emaurri-gutenberg-blocks')}>
						<MediaUpload
							allowedTypes={['image']}
							value={image}
							onSelect={(media) => setAttributes({image: media.id, imageSrc: media.url})}
							render={({open}) => (
								<Button
									isLarge
									onClick={open}>
									{
										!imageSrc ? __('Upload Image', 'emaurri-gutenberg-blocks') : createElement('img', {src: imageSrc})
									}
								</Button>
							)}
						/>
						<TextControl
							label={__('Title', 'emaurri-gutenberg-blocks')}
							value={title}
							onChange={(value) => setAttributes({title: value})}
						/>
						<TextareaControl
							label={__('Text', 'emaurri-gutenberg-blocks')}
							value={text}
							onChange={(value) => setAttributes({text: value})}
						/>
					</PanelBody>
				</InspectorControls>
				{
					Object.keys(qodeblocks).length > 0 ?
						<ServerSideRender
							block={blockName}
							attributes={attributes}
						/>
					: <BlockPlaceholder />
				}
			</Fragment>
		);
	}
}

// Register block type function
registerBlockType(blockName, {
	icon: 'id',
	title: __('Image With Text', 'emaurri-gutenberg-blocks'),
	description: __('A custom image with text block', 'emaurri-gutenberg-blocks'),
	category: 'emaurri-gutenberg-blocks',
	keywords: [
		__('image', 'emaurri-gutenberg-blocks'),
		__('text', 'emaurri-gutenberg-blocks'),
		__('emaurri', 'emaurri-gutenberg-blocks')
	],
	
	edit: ImageWithTextBlock,
	// Render in PHP
	save: () => {
		return null;
	}
});