/**
 * Init swiper slider
 */
export const qodefSwiper = {
	init: function () {
		
		// Listener is important to listen for changes on the block
		var listener = setInterval(() => {
			this.holder = document.querySelectorAll('.qodef-swiper-container');

			if (this.holder.length) {
				[...this.holder].map(holder => {
					qodefSwiper.createSlider(holder);
				});

				clearInterval(listener);
			}
		}, 600);
	},
	createSlider: function ($holder) {
		var sliderOptions = typeof $holder.getAttribute('data-options') !== 'undefined' ? JSON.parse($holder.getAttribute('data-options')) : {};
		var spaceBetween  = sliderOptions.spaceBetween !== undefined && sliderOptions.spaceBetween !== '' ? sliderOptions.spaceBetween : 0;
		var slidesPerView  = sliderOptions.slidesPerView !== undefined && sliderOptions.slidesPerView !== '' ? sliderOptions.slidesPerView : 1;
		var centeredSlides  = sliderOptions.centeredSlides !== undefined && sliderOptions.centeredSlides !== '' ? sliderOptions.centeredSlides : false;
		var loop  = sliderOptions.loop !== undefined && sliderOptions.loop !== '' ? sliderOptions.loop : true;
		var autoplay  = sliderOptions.autoplay !== undefined && sliderOptions.autoplay !== '' ? sliderOptions.autoplay : true;
		var speed  = sliderOptions.speed !== undefined && sliderOptions.speed !== '' ? sliderOptions.speed : 800;
		var customStages  = sliderOptions.customStages !== undefined && sliderOptions.customStages !== '' ? sliderOptions.customStages : false;
		var outsideNavigation  = sliderOptions.outsideNavigation !== undefined && sliderOptions.outsideNavigation === 'yes';
		var nextNavigation  = outsideNavigation ? '.swiper-button-next-' +  sliderOptions.unique : $holder.querySelector('.swiper-button-next');
		var prevNavigation  = outsideNavigation ? '.swiper-button-prev-' +  sliderOptions.unique : $holder.querySelector('.swiper-button-prev');
		var pagination  = $holder.querySelector('.swiper-pagination');
		
		var slidesPerView1440 = sliderOptions.slidesPerView1440 !== undefined && sliderOptions.slidesPerView1440 !== '' ? sliderOptions.slidesPerView1440 : 5;
		var slidesPerView1366 = sliderOptions.slidesPerView1366 !== undefined && sliderOptions.slidesPerView1366 !== '' ? sliderOptions.slidesPerView1366 : 4;
		var slidesPerView1024 = sliderOptions.slidesPerView1024 !== undefined && sliderOptions.slidesPerView1024 !== '' ? sliderOptions.slidesPerView1024 : 3;
		var slidesPerView768 = sliderOptions.slidesPerView768 !== undefined && sliderOptions.slidesPerView768 !== '' ? sliderOptions.slidesPerView768 : 2;
		var slidesPerView680 = sliderOptions.slidesPerView680 !== undefined && sliderOptions.slidesPerView680 !== '' ? sliderOptions.slidesPerView680 : 1;
		var slidesPerView480 = sliderOptions.slidesPerView480 !== undefined && sliderOptions.slidesPerView480 !== '' ? sliderOptions.slidesPerView480 : 1;
		
		if( ! customStages ) {
			if (slidesPerView < 2) {
				slidesPerView1440 = slidesPerView;
				slidesPerView1366 = slidesPerView;
				slidesPerView1024 = slidesPerView;
				slidesPerView768  = slidesPerView;
			} else if (slidesPerView < 3) {
				slidesPerView1440 = slidesPerView;
				slidesPerView1366 = slidesPerView;
				slidesPerView1024 = slidesPerView;
			} else if (slidesPerView < 4) {
				slidesPerView1440 = slidesPerView;
				slidesPerView1366 = slidesPerView;
			} else if (slidesPerView < 5) {
				slidesPerView1440 = slidesPerView;
			}
		}
		
		var $swiper = new Swiper($holder, {
			slidesPerView: slidesPerView,
			centeredSlides: centeredSlides,
			spaceBetween: spaceBetween,
			autoplay: autoplay,
			loop: loop,
			speed: speed,
			navigation: { nextEl: nextNavigation, prevEl: prevNavigation },
			pagination: { el: pagination, type: 'bullets', clickable: true },
			breakpoints: {
				// when window width is <= 480px
				480: {
					slidesPerView: slidesPerView480
				},
				// when window width is <= 680px
				680: {
					slidesPerView: slidesPerView680
				},
				// when window width is <= 768px
				768: {
					slidesPerView: slidesPerView768
				},
				// when window width is <= 1024px
				1024: {
					slidesPerView: slidesPerView1024
				},
				// when window width is <= 1366px
				1366: {
					slidesPerView: slidesPerView1366
				},
				// when window width is <= 1440px
				1440: {
					slidesPerView: slidesPerView1440
				}
			},
			on: {
				init: function () {
					$holder.classList.add('qodef-swiper--initialized');
				}
			}
		});
	}
};

/**
 * Init masonry layout
 */
export const qodefMasonryLayout = {
	init: function () {
		// Listener is important to listen for changes on the block
		var listener = setInterval(() => {
			this.holder = document.querySelectorAll('.qodef-layout--masonry');
			
			if (this.holder.length) {
				[...this.holder].map(holder => {
					qodefMasonryLayout.createMasonry(holder);
				});
				
				clearInterval(listener);
			}
		}, 600);
	},
	createMasonry: function (holder) {
		var $masonry = holder.querySelector('.qodef-grid-inner'),
			$masonryItem = $masonry.querySelector('.qodef-grid-item'),
			size = $masonry.querySelector('.qodef-grid-masonry-sizer').clientWidth;
		
		if (typeof Isotope === 'function') {
			const $isotope = new Isotope($masonry, {
				layoutMode: 'packery',
				itemSelector: '.qodef-grid-item',
				percentPosition: true,
				masonry: {
					columnWidth: '.qodef-grid-masonry-sizer',
					gutter: '.qodef-grid-masonry-gutter'
				}
			});
			
			if (holder.classList.contains('qodef-items--fixed')) {
				qodefMasonryLayout.setFixedImageProportionSize($masonry, $masonryItem, size);
			}
			
			$isotope.layout();
		}
		
		$masonry.classList.add('qodef--masonry-init');
	},
	setFixedImageProportionSize: function (holder, item, size) {
		var padding = parseInt(window.getComputedStyle(item, null).getPropertyValue('padding-left'), 10),
			newSize = size - 2 * padding,
			$squareItem = holder.querySelectorAll('.qodef-item--square'),
			$landscapeItem = holder.querySelectorAll('.qodef-item--landscape'),
			$portraitItem = holder.querySelectorAll('.qodef-item--portrait'),
			$hugeSquareItem = holder.querySelectorAll('.qodef-item--huge-square');
	
		if ($squareItem.length) {
			$squareItem.style.height = newSize;
		}
		
		if ($portraitItem.length) {
			$portraitItem.style.height = Math.round(2 * (newSize + padding));
		}
	
		if (document.documentElement.clientWidth > 680) {
			if ($landscapeItem.length) {
				$landscapeItem.style.height = newSize;
			}
			if ($hugeSquareItem.length) {
				$hugeSquareItem.style.height = Math.round(2 * (newSize + padding));
			}
		} else {
			if ($landscapeItem.length) {
				$landscapeItem.style.height = Math.round(newSize / 2);
			}
			if ($hugeSquareItem.length) {
				$hugeSquareItem.style.height = newSize;
			}
		}
	}
};