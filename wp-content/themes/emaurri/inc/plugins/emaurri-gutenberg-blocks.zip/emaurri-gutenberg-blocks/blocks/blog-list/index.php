<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'EmaurriGutenbergBlogListBlock' ) ) {
	class EmaurriGutenbergBlogListBlock extends EmaurriGutenbergBlocks {
		private static $instance;
		
		public function __construct() {
			// Set block name
			$this->set_block_name( 'blog-list' );
			
			// Set block attributes
			$this->set_block_attributes( $this->block_attributes() );
			
			// Set block render function
			$this->set_block_render_function( array( $this, 'render_function' ) );
			
			parent::__construct();
		}
		
		public static function get_instance() {
			if ( self::$instance == null ) {
				self::$instance = new self();
			}
			
			return self::$instance;
		}
		
		private function block_attributes() {
			$attributes = array_merge(
				$this->map_core_options(),
				$this->map_list_options(),
				$this->map_list_responsive_options(),
				$this->map_query_options()
			);
			
			return $attributes;
		}
		
		function render_function( $props ) {
			
			if ( class_exists( 'EmaurriCore_Blog_List_Shortcode' ) ) {
				$props['custom_class'] = $this->block_custom_class( $props );
				
				return EmaurriCore_Blog_List_Shortcode::call_shortcode( $props );
			}
			
			return null;
		}
	}
	
	EmaurriGutenbergBlogListBlock::get_instance();
}