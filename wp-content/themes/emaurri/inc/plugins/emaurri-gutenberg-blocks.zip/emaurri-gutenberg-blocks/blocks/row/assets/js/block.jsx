// Global wp objects and variables
const {__} = wp.i18n;
const {registerBlockType} = wp.blocks;
const {Component, Fragment, createElement} = wp.element;
const {InspectorControls, InnerBlocks} = wp.blockEditor;
const {PanelBody, TextControl, RangeControl, SelectControl, ColorPicker, TextareaControl} = wp.components;

// Block namespace + name
const blockName = 'emaurri-gutenberg-blocks/row';

class ColumnBlock extends Component {
	constructor() {
		super(...arguments);
	}
	
	render() {
		const {columns_layout} = this.props;
		
		let columnsHTML = [];
		
		for (let i = 1; i <= Number(columns_layout); i++) {
			columnsHTML.push(createElement('div', {
					className: 'qodef-grid-item',
				},
				createElement(InnerBlocks, {
					templateLock: false,
					renderAppender: createElement(InnerBlocks.ButtonBlockAppender),
				})
			));
		}
		
		return (
			columnsHTML
		);
	}
}

class RowBlock extends Component {
	constructor() {
		super(...arguments);
	}
	
	render() {
		const {attributes, setAttributes} = this.props;
		const {
			columns_layout,
		} = attributes;
		
		let rowClasses = ['qodef-grid qodef-layout--columns'];
		if (columns_layout) {
			rowClasses.push('qodef-col-num--' + Number(columns_layout));
		}
		
		if(this.props.className) {
			rowClasses.push(this.props.className);
		}
		return (
			<Fragment>
				<InspectorControls>
					<PanelBody title={__('Row Settings', 'emaurri-gutenberg-blocks')}>
						<SelectControl
							label={__('Columns Layout', 'emaurri-gutenberg-blocks')}
							value={columns_layout}
							options={[
								{label: __('100%', 'emaurri-gutenberg-blocks'), value: '1'},
								{label: __('50% - 50%', 'emaurri-gutenberg-blocks'), value: '2'},
								{label: __('33% - 33% - 33%', 'emaurri-gutenberg-blocks'), value: '3'},
								{label: __('25% - 25% - 25% - 25%', 'emaurri-gutenberg-blocks'), value: '4'},
								{label: __('16.67% - 16.67% - 16.67% - 16.67% - 16.67% - 16.67%', 'emaurri-gutenberg-blocks'), value: '6'},
							]}
							onChange={(value) => setAttributes({columns_layout: value})}
						/>
					</PanelBody>
				</InspectorControls>
				{
					createElement('div', {
							className: rowClasses.map(item => item).join(' '),
						},
						createElement('div', {
								className: 'qodef-grid-inner clear',
							},
							createElement(ColumnBlock, {
								columns_layout: columns_layout,
							})
						),
					)
				}
			</Fragment>
		);
	}
}

// Register block type function
registerBlockType(blockName, {
	icon: 'backup',
	title: __('Row Layout', 'emaurri-gutenberg-blocks'),
	description: __('A custom row block', 'emaurri-gutenberg-blocks'),
	category: 'emaurri-gutenberg-blocks',
	keywords: [
		__('row', 'emaurri-gutenberg-blocks'),
		__('columns', 'emaurri-gutenberg-blocks'),
		__('emaurri', 'emaurri-gutenberg-blocks')
	],
	
	edit: RowBlock,
	// Render in PHP
	save: (props) => {
		return (
			<InnerBlocks.Content />
		);
	}
});