<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'EmaurriGutenbergBlocks' ) ) {
	class EmaurriGutenbergBlocks {
		private $blocks_namespace;
		private $block_name;
		private $block_frontend_style;
		private $block_editor_style;
		private $block_editor_script;
		private $block_attributes = array();
		private $block_render_function = '';
		
		public function __construct() {
			
			// Set namespace for blocks
			$this->set_blocks_namespace( 'emaurri-gutenberg-blocks' );
			
			// Enqueue blocks assets
			add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_scripts' ) );
			
			// Register block
			add_action( 'init', array( $this, 'register_block' ) );
		}
		
		public function get_blocks_namespace() {
			return $this->blocks_namespace;
		}
		
		public function set_blocks_namespace( $blocks_namespace ) {
			$this->blocks_namespace = $blocks_namespace;
		}
		
		public function get_block_name() {
			return $this->block_name;
		}
		
		public function set_block_name( $block_name ) {
			$this->block_name = $block_name;
		}
		
		public function get_block_frontend_style() {
			return $this->block_frontend_style;
		}
		
		public function set_block_frontend_style( $block_frontend_style ) {
			$this->block_frontend_style = $block_frontend_style;
		}
		
		public function get_block_editor_style() {
			return $this->block_editor_style;
		}
		
		public function set_block_editor_style( $block_editor_style ) {
			$this->block_editor_style = $block_editor_style;
		}
		
		public function get_block_editor_script() {
			return $this->block_editor_script;
		}
		
		public function set_block_editor_script( $block_editor_script ) {
			$this->block_editor_script = $block_editor_script;
		}
		
		public function get_block_attributes() {
			return $this->block_attributes;
		}
		
		public function set_block_attributes( $block_attributes ) {
			$this->block_attributes = $block_attributes;
		}
	
		public function get_block_render_function() {
			return $this->block_render_function;
		}
		
		public function set_block_render_function( $block_render_function ) {
			$this->block_render_function = $block_render_function;
		}
		
		function enqueue_scripts() {
			// Enqueue main theme's scripts
			$this->include_themes_assets();
			
			// Enqueue main blocks style
			wp_enqueue_style( 'emaurri-gutenberg-blocks-style', EMAURRI_GUTENBERG_ASSETS_URL_PATH . '/css/blocks.min.css' );
			
			// Enqueue main blocks script
			wp_enqueue_script( 'emaurri-gutenberg-blocks-script', EMAURRI_GUTENBERG_ASSETS_URL_PATH . '/js/blocks.min.js', array( 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-editor', 'wp-data' ) );
			
			// Make blocks available for translation
			wp_set_script_translations( 'emaurri-gutenberg-blocks-script', 'emaurri-gutenberg-blocks', EMAURRI_GUTENBERG_REL_PATH . '/languages' );
		}
		
		function include_themes_assets() {
			
			// Temporary solution to include 3rd party scripts from theme
			if ( qode_framework_is_installed( 'theme' ) ) {
				$theme_instance = Emaurri_Handler::get_instance();
				
				// Include theme's 3rd party plugins styles
				$theme_instance->include_plugins_styles();
				
				// Include theme's 3rd party plugins scripts
				$theme_instance->include_plugins_scripts();
				emaurri_include_masonry_scripts();
			}
		}
		
		function register_block() {
			
			register_block_type( $this->get_blocks_namespace() . '/' . $this->get_block_name(), array(
				'style'           => $this->get_block_frontend_style(),
				'editor_style'    => $this->get_block_editor_style(),
				'editor_script'   => $this->get_block_editor_script(),
				'attributes'      => $this->get_block_attributes(),
				'render_callback' => $this->get_block_render_function()
			) );
		}
		
		function block_custom_class( $props ) {
			$classes = array( 'qodef--block' );
	
			$classes[] = $this->get_blocks_namespace() . '-' . $this->get_block_name();
			
			if ( isset( $props['className'] ) && ! empty( $props['className'] ) ) {
				$classes[] = esc_attr( $props['className'] );
			}
			
			return implode( ' ', $classes );
		}
		
		function map_core_options( $args = array() ) {
			return array(
				'className'       => array(
					'type' => 'string',
				),
			);
		}
		
		function map_list_options( $args = array() ) {
			return array(
				'behavior' => array(
					'type'    => 'select',
					'default' => isset( $args['behavior_default'] ) && ! empty( $args['behavior_default'] ) ? esc_attr( $args['behavior_default'] ) : 'columns'
				),
				'columns'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_default'] ) && ! empty( $args['columns_default'] ) ? intval( $args['columns_default'] ) : 2
				),
				'space'  => array(
					'type'    => 'select',
					'default' => isset( $args['space_default'] ) && ! empty( $args['space_default'] ) ? esc_attr( $args['space_default'] ) : 'normal'
				),
			);
		}
		
		function map_list_responsive_options( $args = array() ) {
			return array(
				'columns_responsive'  => array(
					'type'    => 'select',
					'default' => isset( $args['columns_responsive_default'] ) && ! empty( $args['columns_responsive_default'] ) ? esc_attr( $args['columns_responsive_default'] ) : 'predefined'
				),
				'columns_1440'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_1440_default'] ) && ! empty( $args['columns_1440_default'] ) ? intval( $args['columns_1440_default'] ) : 3
				),
				'columns_1366'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_1366_default'] ) && ! empty( $args['columns_1366_default'] ) ? intval( $args['columns_1366_default'] ) : 3
				),
				'columns_1024'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_1024_default'] ) && ! empty( $args['columns_1024_default'] ) ? intval( $args['columns_1024_default'] ) : 3
				),
				'columns_768'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_768_default'] ) && ! empty( $args['columns_768_default'] ) ? intval( $args['columns_768_default'] ) : 3
				),
				'columns_680'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_680_default'] ) && ! empty( $args['columns_680_default'] ) ? intval( $args['columns_680_default'] ) : 3
				),
				'columns_480'  => array(
					'type'    => 'range',
					'default' => isset( $args['columns_480_default'] ) && ! empty( $args['columns_480_default'] ) ? intval( $args['columns_480_default'] ) : 3
				),
			);
		}
		
		function map_query_options( $args = array() ) {
			return array(
				'posts_per_page' => array(
					'type'    => 'range',
					'default' => isset( $args['posts_per_page_default'] ) && ! empty( $args['posts_per_page_default'] ) ? intval( $args['posts_per_page_default'] ) : 4
				),
				'orderby'        => array(
					'type'    => 'select',
					'default' => 'date'
				),
				'order'          => array(
					'type'    => 'select',
					'default' => 'desc'
				),
			);
		}
	}
}