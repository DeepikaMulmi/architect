<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'EmaurriGutenbergCounterBlock' ) ) {
	class EmaurriGutenbergCounterBlock extends EmaurriGutenbergBlocks {
		private static $instance;
		
		public function __construct() {
			// Set block name
			$this->set_block_name( 'counter' );
			
			// Set block attributes
			$this->set_block_attributes( $this->block_attributes() );
			
			// Set block render function
			$this->set_block_render_function( array( $this, 'render_function' ) );
			
			parent::__construct();
		}
		
		public static function get_instance() {
			if ( self::$instance == null ) {
				self::$instance = new self();
			}
			
			return self::$instance;
		}
		
		private function block_attributes() {
			$attributes = array_merge(
				$this->map_core_options(),
				array(
					'start_digit'      => array(
						'type'    => 'number',
						'default' => 0,
					),
					'end_digit'        => array(
						'type'    => 'number',
						'default' => 30,
					),
					'step_digit'       => array(
						'type'    => 'number',
						'default' => 1,
					),
					'step_delay'       => array(
						'type' => 'number',
					),
					'digit_label'      => array(
						'type' => 'string',
					),
					'digit_font_size'  => array(
						'type' => 'number',
					),
					'digit_color'      => array(
						'type' => 'color',
					),
					'title'            => array(
						'type' => 'string',
					),
					'title_tag'        => array(
						'type'    => 'select',
						'default' => 'p',
					),
					'title_color'      => array(
						'type' => 'color',
					),
					'title_margin_top' => array(
						'type' => 'number',
					),
					'text'             => array(
						'type' => 'string',
					),
					'text_color'       => array(
						'type' => 'color',
					),
					'text_margin_top'  => array(
						'type' => 'number',
					),
				)
			);
			
			return $attributes;
		}
		
		function render_function( $props ) {
			
			if ( class_exists( 'EmaurriCore_Counter_Shortcode' ) ) {
				$props['custom_class'] = $this->block_custom_class( $props );
				
				return EmaurriCore_Counter_Shortcode::call_shortcode( $props );
			}
			
			return null;
		}
	}
	
	EmaurriGutenbergCounterBlock::get_instance();
}