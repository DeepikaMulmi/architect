// Global wp objects and variables
const {__} = wp.i18n;
const {createElement} = wp.element;

const BlockPlaceholder = () => {
	
	return (
		createElement('div', {
				className: 'components-placeholder qodef-block-placeholder'
			},
			createElement('p', {
				className: 'qodef-block-placeholder-label'
			}, __('Fill block options in order to display it.', 'emaurri-gutenberg-blocks') )
		)
	);
};

export default BlockPlaceholder;