// Global wp objects and variables
const {__} = wp.i18n;
const {registerBlockType} = wp.blocks;
const {Component, Fragment, createElement} = wp.element;
const {InspectorControls} = wp.blockEditor;
const {PanelBody, TextControl, RangeControl, SelectControl, ColorPicker, TextareaControl} = wp.components;

// Block namespace + name
const blockName = 'emaurri-gutenberg-blocks/counter';

// Import editor scripts
import qodefCounter from './editor-script.jsx';

class CounterBlock extends Component {
	constructor() {
		super(...arguments);
	}
	
	componentDidMount() {
		this.initShortcode();
	}
	
	componentDidUpdate(prevProps, prevState) {
		const {attributes} = this.props;
		
		if (prevProps.attributes.start_digit !== attributes.start_digit || prevProps.attributes.end_digit !== attributes.end_digit || prevProps.attributes.step_digit !== attributes.step_digit || prevProps.attributes.step_delay !== attributes.step_delay || prevProps.attributes.digit_label !== attributes.digit_label) {
			this.initShortcode();
		}
	}
	
	initShortcode() {
		typeof qodefCounter === 'object' && qodefCounter.init();
	}
	
	render() {
		const {attributes, setAttributes} = this.props;
		const {
			start_digit,
			end_digit,
			step_digit,
			step_delay,
			digit_label,
			digit_font_size,
			digit_color,
			title,
			title_tag,
			title_color,
			title_margin_top,
			text,
			text_color,
			text_margin_top,
		} = attributes;
		
		let digitStyles = {};
		if (digit_font_size) {
			digitStyles.fontSize = parseInt(digit_font_size, 10) + 'px';
		}
		if (digit_color) {
			digitStyles.color = digit_color.hex;
		}

		let titleStyles = {};
		if (title_margin_top) {
			titleStyles.marginTop = parseInt(title_margin_top, 10) + 'px';
		}
		if (title_color) {
			titleStyles.color = title_color.hex;
		}
		
		let textStyles = {};
		if (text_margin_top) {
			textStyles.marginTop = parseInt(text_margin_top, 10) + 'px';
		}
		if (text_color) {
			textStyles.color = text_color.hex;
		}
		
		return (
			<Fragment>
				<InspectorControls>
					<PanelBody title={__('Digit Settings', 'emaurri-gutenberg-blocks')}>
						<TextControl
							label={__('Start Digit', 'emaurri-gutenberg-blocks')}
							value={start_digit}
							onChange={(value) => setAttributes({start_digit: value})}
						/>
						<TextControl
							label={__('End Digit', 'emaurri-gutenberg-blocks')}
							value={end_digit}
							onChange={(value) => setAttributes({end_digit: value})}
						/>
						<RangeControl
							label={__('Step Between Digits', 'emaurri-gutenberg-blocks')}
							value={step_digit}
							min={1}
							max={1000}
							onChange={(value) => setAttributes({step_digit: value})}
						/>
						<TextControl
							label={__('Step Delay', 'emaurri-gutenberg-blocks')}
							value={step_delay}
							onChange={(value) => setAttributes({step_delay: value})}
						/>
						<TextControl
							label={__('Digit Label', 'emaurri-gutenberg-blocks')}
							value={digit_label}
							onChange={(value) => setAttributes({digit_label: value})}
						/>
						<RangeControl
							label={__('Digit Font Size (px)', 'emaurri-gutenberg-blocks')}
							value={digit_font_size}
							min={0}
							max={500}
							onChange={(value) => setAttributes({digit_font_size: value})}
						/>
						{createElement('p', {
							className: 'qodef-color-picker-label'
						}, __('Digit Color', 'emaurri-gutenberg-blocks'))}
						<ColorPicker
							color={digit_color}
							onChangeComplete={(value) => setAttributes({digit_color: value})}
							disableAlpha
						/>
					</PanelBody>
					<PanelBody title={__('Content Settings', 'emaurri-gutenberg-blocks')} initialOpen={false}>
						<TextControl
							label={__('Title', 'emaurri-gutenberg-blocks')}
							value={title}
							onChange={(value) => setAttributes({title: value})}
						/>
						<SelectControl
							label={__('Title Tag', 'emaurri-gutenberg-blocks')}
							value={title_tag}
							options={[
								{label: __('H1', 'emaurri-gutenberg-blocks'), value: 'h1'},
								{label: __('H2', 'emaurri-gutenberg-blocks'), value: 'h2'},
								{label: __('H3', 'emaurri-gutenberg-blocks'), value: 'h3'},
								{label: __('H4', 'emaurri-gutenberg-blocks'), value: 'h4'},
								{label: __('H5', 'emaurri-gutenberg-blocks'), value: 'h5'},
								{label: __('H6', 'emaurri-gutenberg-blocks'), value: 'h6'},
								{label: __('Paragraph', 'emaurri-gutenberg-blocks'), value: 'p'},
							]}
							onChange={(value) => setAttributes({title_tag: value})}
						/>
						{createElement('p', {
							className: 'qodef-color-picker-label'
						}, __('Title Color', 'emaurri-gutenberg-blocks'))}
						<ColorPicker
							color={title_color}
							onChangeComplete={(value) => setAttributes({title_color: value})}
							disableAlpha
						/>
						<TextControl
							label={__('Title Margin Top (px)', 'emaurri-gutenberg-blocks')}
							value={title_margin_top}
							onChange={(value) => setAttributes({title_margin_top: value})}
						/>
						<TextareaControl
							label={__('Text', 'emaurri-gutenberg-blocks')}
							value={text}
							onChange={(value) => setAttributes({text: value})}
						/>
						{createElement('p', {
							className: 'qodef-color-picker-label'
						}, __('Text Color', 'emaurri-gutenberg-blocks'))}
						<ColorPicker
							color={text_color}
							onChangeComplete={(value) => setAttributes({text_color: value})}
							disableAlpha
						/>
						<TextControl
							label={__('Text Margin Top (px)', 'emaurri-gutenberg-blocks')}
							value={text_margin_top}
							onChange={(value) => setAttributes({text_margin_top: value})}
						/>
					</PanelBody>
				</InspectorControls>
				{
					createElement('div', {
							className: 'qodef-shortcode qodef-m qodef-counter qodef-layout--simple ' + this.props.className,
							'data-start-digit': start_digit,
							'data-end-digit': end_digit,
							'data-step-digit': step_digit,
							'data-step-delay': step_delay,
							'data-digit-label': digit_label,
						},
						createElement('div', {
								className: 'qodef-m-digit-wrapper',
							},
							createElement('span', {
									className: 'qodef-m-digit',
									style: digitStyles
								},
							)
						),
						(title || text) && createElement('div', {
								className: 'qodef-m-content',
							},
							title && createElement(title_tag, {
									className: 'qodef-m-title',
									style: titleStyles
								}, title
							),
							text && createElement('p', {
									className: 'qodef-m-text',
									style: textStyles
								}, text
							)
						),
					)
				}
			</Fragment>
		);
	}
}

// Register block type function
registerBlockType(blockName, {
	icon: 'backup',
	title: __('Counter', 'emaurri-gutenberg-blocks'),
	description: __('A custom counter block', 'emaurri-gutenberg-blocks'),
	category: 'emaurri-gutenberg-blocks',
	keywords: [
		__('counter', 'emaurri-gutenberg-blocks'),
		__('number', 'emaurri-gutenberg-blocks'),
		__('emaurri', 'emaurri-gutenberg-blocks')
	],
	
	edit: CounterBlock,
	// Render in PHP
	save: () => {
		return null;
	}
});