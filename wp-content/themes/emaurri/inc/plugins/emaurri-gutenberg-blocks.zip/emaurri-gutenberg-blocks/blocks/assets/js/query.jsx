// Global wp objects and variables
const {__} = wp.i18n;
const {PanelBody, RangeControl, SelectControl} = wp.components;

const QueryOptions = ({props, initialOpen = false}) => {
	const {attributes, setAttributes} = props;
	const {
		posts_per_page,
		orderby,
		order,
	} = attributes;
	
	return (
		<PanelBody title={__('Query Settings', 'emaurri-gutenberg-blocks')} initialOpen={Boolean(initialOpen)}>
			<RangeControl
				label={__('Posts per Page', 'emaurri-gutenberg-blocks')}
				value={posts_per_page}
				min={1}
				max={50}
				onChange={(value) => setAttributes({posts_per_page: value})}
			/>
			<SelectControl
				label={__('Order By', 'emaurri-gutenberg-blocks')}
				value={orderby}
				options={[
					{label: __('Date', 'emaurri-gutenberg-blocks'), value: 'date'},
					{label: __('ID', 'emaurri-gutenberg-blocks'), value: 'ID'},
					{label: __('Menu Order', 'emaurri-gutenberg-blocks'), value: 'menu_order'},
					{label: __('Post Name', 'emaurri-gutenberg-blocks'), value: 'name'},
					{label: __('Random', 'emaurri-gutenberg-blocks'), value: 'rand'},
					{label: __('Title', 'emaurri-gutenberg-blocks'), value: 'title'},
				]}
				onChange={(value) => setAttributes({orderby: value})}
			/>
			<SelectControl
				label={__('Order', 'emaurri-gutenberg-blocks')}
				value={order}
				options={[
					{label: __('Descending', 'emaurri-gutenberg-blocks'), value: 'DESC'},
					{label: __('Ascending', 'emaurri-gutenberg-blocks'), value: 'ASC'},
				]}
				onChange={(value) => setAttributes({order: value})}
			/>
		</PanelBody>
	)
};

export default QueryOptions;