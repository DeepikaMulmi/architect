// Global wp objects and variables
const {__} = wp.i18n;
const {PanelBody, RangeControl, SelectControl} = wp.components;

const ListResponsiveOptions = ({props, initialOpen = false}) => {
	const {attributes, setAttributes} = props;
	const {
		columns_responsive,
		columns_1440,
		columns_1366,
		columns_1024,
		columns_768,
		columns_680,
		columns_480,
	} = attributes;
	
	return(
		<PanelBody title={__('List - Responsive Settings', 'emaurri-gutenberg-blocks')} initialOpen={Boolean(initialOpen)}>
			<SelectControl
				label={__('Columns Responsive', 'emaurri-gutenberg-blocks')}
				value={columns_responsive}
				options={[
					{label: __('Predefined', 'emaurri-gutenberg-blocks'), value: 'predefined'},
					{label: __('Custom', 'emaurri-gutenberg-blocks'), value: 'custom'},
				]}
				onChange={(value) => setAttributes({columns_responsive: value})}
			/>
			<RangeControl
				label={__('Columns Number 1367px - 1440px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_1440}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_1440: value})}
			/>
			<RangeControl
				label={__('Columns Number 1025px - 1366px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_1366}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_1366: value})}
			/>
			<RangeControl
				label={__('Columns Number 769px - 1024px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_1024}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_1024: value})}
			/>
			<RangeControl
				label={__('Columns Number 681px - 768px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_768}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_768: value})}
			/>
			<RangeControl
				label={__('Columns Number 481px - 680px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_680}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_680: value})}
			/>
			<RangeControl
				label={__('Columns Number 0 - 480px', 'emaurri-gutenberg-blocks')}
				help={__('This option is available only for custom columns responsive', 'emaurri-gutenberg-blocks')}
				value={columns_480}
				min={1}
				max={6}
				onChange={(value) => setAttributes({columns_480: value})}
			/>
		</PanelBody>
	)
};

export default ListResponsiveOptions;