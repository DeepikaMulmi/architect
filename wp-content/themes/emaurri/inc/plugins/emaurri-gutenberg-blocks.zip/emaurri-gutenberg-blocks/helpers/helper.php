<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'emaurri_gutenberg_extend_block_categories' ) ) {
	/**
	 * Function that extend default array of block categories
	 *
	 * @param $default_categories array - Array of block categories
	 * @param $post WP_Post - Post being loaded
	 *
	 * @return array
	 */
	function emaurri_gutenberg_extend_block_categories( $default_categories, $post ) {
		
		return array_merge(
			$default_categories,
			array(
				array(
					'slug'  => 'emaurri-gutenberg-blocks',
					'title' => esc_html__( 'Emaurri', 'emaurri-gutenberg-blocks' )
				)
			)
		);
	}
	
	add_filter( 'block_categories', 'emaurri_gutenberg_extend_block_categories', 10, 2 );
}