// Load global variables
const glob = require("glob");

// Load specific variables
const TerserJSPlugin = require('terser-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const globImporter = require('node-sass-glob-importer');

// Helpers
const productionMode = process.env.NODE_ENV === 'production';

// Entry files
const blockFiles  = glob.sync('./blocks/*/assets/js/block.jsx');
const scssFiles   = glob.sync('./assets/css/scss/blocks.scss');

const files = [...blockFiles, ...scssFiles];

// Compiler task
module.exports = {
	mode: productionMode ? 'production' : 'development',
	entry: files,
	output: {
		path: __dirname + '/assets/js',
		filename: productionMode ? 'blocks.min.js' : 'blocks.js',
	},
	optimization: {
		minimizer: [new TerserJSPlugin(), new OptimizeCSSAssetsPlugin()],
	},
	module: {
		rules: [
			{
				test: /\.(js|jsx)$/,
				exclude: /node_modules/,
				loader: "babel-loader"
			},
			{
				test: /\.scss$/,
				use: [
					{
						loader: MiniCssExtractPlugin.loader,
					},
					{
						loader: "css-loader", // translates CSS into CommonJS
					},
					{
						loader: 'postcss-loader', // Modify css files (autoprefixer)
					},
					{
						loader: "sass-loader", // compiles Sass to CSS, using Node Sass by default
						options: {
							importer: globImporter()
						}
					},
				]
			}
		],
	},
	plugins: [
		new MiniCssExtractPlugin({
			filename: productionMode ? '../css/blocks.min.css' : '../css/blocks.css'
		})
	],
};