<div class="qodef-e-info-author">
	<?php echo  esc_html__( 'by ', 'emaurri-core' ); ?>
	<?php the_author_meta( 'display_name' ); ?>
</div>
