<?php

include_once EMAURRI_CORE_INC_PATH . '/icons/simple-line-icons/class-emaurricore-simple-line-icons-pack.php';
