<?php

include_once EMAURRI_CORE_INC_PATH . '/header/layouts/minimal-centered/helper.php';
include_once EMAURRI_CORE_INC_PATH . '/header/layouts/minimal-centered/class-emaurricore-minimal-centered-header.php';
include_once EMAURRI_CORE_INC_PATH . '/header/layouts/minimal-centered/dashboard/admin/minimal-centered-header-options.php';
include_once EMAURRI_CORE_INC_PATH . '/header/layouts/minimal-centered/dashboard/meta/minimal-centered-header-meta.php';
