<?php

include_once EMAURRI_CORE_INC_PATH . '/content/helper.php';
