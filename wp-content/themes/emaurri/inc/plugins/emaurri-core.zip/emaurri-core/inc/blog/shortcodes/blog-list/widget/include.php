<?php

include_once EMAURRI_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-emaurricore-blog-list-widget.php';
