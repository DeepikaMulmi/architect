<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-emaurricore-woocommerce-dropdown-cart-widget.php';
