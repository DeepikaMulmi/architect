<?php

include_once EMAURRI_CORE_INC_PATH . '/mobile-header/helper.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/class-emaurricore-mobile-header.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/class-emaurricore-mobile-headers.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/template-functions.php';
