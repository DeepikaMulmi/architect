<?php

include_once EMAURRI_CORE_INC_PATH . '/icons/ionicons/class-emaurricore-ionicons-pack.php';
