<?php

include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/side-area/helper.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/side-area/class-emaurricore-side-area-mobile-header.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/side-area/dashboard/admin/side-area-mobile-header-options.php';
