(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.emaurri_core_clients_list             = {};
	qodefCore.shortcodes.emaurri_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
