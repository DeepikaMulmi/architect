<?php

include_once EMAURRI_CORE_INC_PATH . '/icons/elegant-icons/class-emaurricore-elegant-icons-pack.php';
