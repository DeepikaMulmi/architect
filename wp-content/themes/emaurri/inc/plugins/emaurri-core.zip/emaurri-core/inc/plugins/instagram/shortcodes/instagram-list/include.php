<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-emaurricore-instagram-list-shortcode.php';
