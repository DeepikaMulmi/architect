<?php

include_once EMAURRI_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';
