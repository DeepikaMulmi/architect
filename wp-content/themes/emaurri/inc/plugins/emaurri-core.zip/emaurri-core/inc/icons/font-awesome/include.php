<?php

include_once EMAURRI_CORE_INC_PATH . '/icons/font-awesome/class-emaurricore-font-awesome-pack.php';
