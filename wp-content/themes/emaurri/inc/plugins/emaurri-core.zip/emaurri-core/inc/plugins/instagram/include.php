<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/instagram/helper.php';
