<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/helper.php';
include_once EMAURRI_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/class-emaurricore-woocommerce-yith-quick-view.php';
