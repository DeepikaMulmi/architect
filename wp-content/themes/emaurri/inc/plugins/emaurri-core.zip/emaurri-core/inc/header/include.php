<?php

include_once EMAURRI_CORE_INC_PATH . '/header/helper.php';
include_once EMAURRI_CORE_INC_PATH . '/header/class-emaurricore-header.php';
include_once EMAURRI_CORE_INC_PATH . '/header/class-emaurricore-headers.php';
include_once EMAURRI_CORE_INC_PATH . '/header/template-functions.php';
