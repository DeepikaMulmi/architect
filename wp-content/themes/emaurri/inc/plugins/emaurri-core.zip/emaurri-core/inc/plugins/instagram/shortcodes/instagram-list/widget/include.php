<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-emaurricore-instagram-list-widget.php';
