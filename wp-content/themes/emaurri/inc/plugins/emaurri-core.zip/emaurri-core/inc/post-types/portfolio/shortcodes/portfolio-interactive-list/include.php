<?php

include_once EMAURRI_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-interactive-list/class-emaurricore-portfolio-interactive-list-shortcode.php';
