<?php

include_once EMAURRI_CORE_CPT_PATH . '/class-emaurricore-custom-post-types.php';
