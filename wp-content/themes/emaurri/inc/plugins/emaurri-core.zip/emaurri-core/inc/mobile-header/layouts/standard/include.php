<?php

include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/standard/helper.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/standard/class-emaurricore-standard-mobile-header.php';
include_once EMAURRI_CORE_INC_PATH . '/mobile-header/layouts/standard/dashboard/admin/standard-mobile-header-options.php';
