<div class="qodef-ptf-list-showcase-meta-item">
	<span class="qodef-ptf-meta-item-date-year"><?php the_time( 'M. Y' ); ?></span>

	<?php emaurri_core_list_sc_template_part( 'post-types/portfolio/shortcodes/portfolio-interactive-list', 'post-info/title', '', $params ); ?>

	<?php emaurri_core_list_sc_template_part( 'post-types/portfolio/shortcodes/portfolio-interactive-list', 'post-info/category', '', $params ); ?>
</div>
