<?php

include_once EMAURRI_CORE_PLUGINS_PATH . '/woocommerce/class-emaurricore-woocommerce.php';
