<?php

include_once EMAURRI_CORE_INC_PATH . '/media/helper.php';
