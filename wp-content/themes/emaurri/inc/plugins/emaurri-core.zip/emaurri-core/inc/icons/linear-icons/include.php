<?php

include_once EMAURRI_CORE_INC_PATH . '/icons/linear-icons/class-emaurricore-linear-icons-pack.php';
