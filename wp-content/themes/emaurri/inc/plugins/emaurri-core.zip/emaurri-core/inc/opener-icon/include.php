<?php

include_once EMAURRI_CORE_INC_PATH . '/opener-icon/helper.php';
