<?php

interface QodeFrameworkChildInterface {
	public function get_name();
}
